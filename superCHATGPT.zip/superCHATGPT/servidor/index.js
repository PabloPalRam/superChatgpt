import { Comunicacion } from "./modulos/comunicacion.js";

let comunicacion = new Comunicacion(5500);
