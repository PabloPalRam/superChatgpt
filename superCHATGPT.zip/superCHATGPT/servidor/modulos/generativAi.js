const API_KEY = "sk-proj-qLoo2ipDynZUGbiahXKFT3BlbkFJFLf8vJ364PGCkkI44l9P";

async function GenerativAI(prompt) {
    console.log('prompt '+prompt);
  const response = await fetch(`https://api.openai.com/v1/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${API_KEY}`,
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo-instruct",
      prompt: prompt,
      max_tokens: 20,
    }),
  });

  const data = await response.json();
  return data;
}

export { GenerativAI };


