import { Comunicacion } from "./modulos/comunicacion.js";
import { Grabacion } from "./modulos/grabacion.js";

let comunicacion = new Comunicacion('localhost', 5500);
let grabacion = new Grabacion(comunicacion);

