class Comunicacion {
    constructor(url, port) {
        this.messages = {
            enviar: null,
        };
        this.ws = new WebSocket('ws://' + url + ':' + port);
        this.conectado = false;
        this.ws.onopen = (event) => {
            this.conectado = true;
        };
        this.onmessage = (event) => {
            
        };
        this.ws.onerror = (event) => {
            this.conectado = false;
        };
        this.ws.onclose = (event) => {
            this.conectado = false;
        };
    }

    manageMensaje(msgClient){
        if(msgClient != null || msgClient!=''){
            console.log('enviar mensaje');
            console.log('msgClient  '+msgClient);
            this.messages.enviar = msgClient;
            console.log(this.messages.enviar);
            this.ws.send(JSON.stringify(this.messages.enviar));
        }

    }


}

export { Comunicacion };
