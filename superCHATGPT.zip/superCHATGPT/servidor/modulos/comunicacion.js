import { WebSocketServer } from 'ws'
import { GenerativAI } from './generativAi.js';

class Comunicacion {
    constructor(port) {
        this.wss = new WebSocketServer({ port: port });
        
        this.wss.on('connection', (ws) => {
            console.log('Cliente conectado');

            // Manejar mensajes entrantes del cliente
            ws.on('message', async (message) => {
                const decodedMessage = message.toString('utf-8');
                console.log('Mensaje recibido del cliente:', decodedMessage);


                try {
                    const response = await GenerativAI(decodedMessage);
          
                    if (response.choices && response.choices.length > 0 && response.choices[0].text) {
                      const reply = response.choices[0].text.trim();
                      console.log('ChatGPT generado:', reply);
                      ws.send(reply);
                    } else {
                      console.error('Respuesta inesperada de OpenAI:', response);
                      ws.send('No se recibió una respuesta válida de OpenAI.');
                    }
                  } catch (error) {
                    console.error('Error al obtener respuesta de OpenAI:', error);
                    ws.send('Error al obtener respuesta del servidor.');
                  }

            });
        });
    }

}

export { Comunicacion };






